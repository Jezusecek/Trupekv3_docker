{{--The below text may be dynamic based upon language and scenario.--}}
{{--It's safer to add new text sections here rather than altering existing ones.--}}
<h1 class="list-heading">{{ $title }}</h1>
<h5>{{ $subtitle }}</h5>
<p>{{ $details }}</p>