User-agent: *
@if($allowRobots)
Disallow:
@else
Disallow: /
@endif