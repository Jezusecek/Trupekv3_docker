<?php
/**
 * Pagination Language Lines
 * The following language lines are used by the paginator library to build
 * the simple pagination links.
 */
return [

    'previous' => '&laquo; 이전',
    'next'     => '다음 &raquo;',

];
